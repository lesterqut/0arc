/**
 * Vercel serverless function entry point for Supabase routes.
 *
 * - POST /api/supabase/auth/signup
 * - POST /api/supabase/auth/signin
 * - POST /api/supabase/auth/signout
 * - POST /api/supabase/data
 *
 * Vercel ignores files and directories whose names begin with an underscore
 * at routing time, so helpers in api/_lib/* are never accidentally exposed
 * as HTTP routes.
 */
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { handleSignup, handleSignin, handleSignout } from './auth';
import { handleSupabaseData } from './data';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  const pathname = typeof req.url === 'string' ? new URL(req.url, 'http://localhost').pathname : '/';

  if (!pathname.startsWith('/api/supabase/')) {
    return res.status(404).json({ ok: false, error: 'Not found' });
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, error: 'POST only' });
  }

  let body = '{}';
  try {
    body = req.body ? JSON.stringify(req.body) : '{}';
  } catch {
    body = '{}';
  }

  const apiReq = {
    method: req.method,
    url: pathname,
    headers: req.headers as Record<string, string | undefined>,
    body,
    query: {},
  } as const;

  let response: { status: number; body: unknown };
  if (pathname === '/api/supabase/auth/signup') {
    response = await handleSignup(apiReq);
  } else if (pathname === '/api/supabase/auth/signin') {
    response = await handleSignin(apiReq);
  } else if (pathname === '/api/supabase/auth/signout') {
    response = await handleSignout(apiReq);
  } else if (pathname === '/api/supabase/data') {
    response = await handleSupabaseData(apiReq);
  } else {
    response = { status: 404, body: { ok: false, error: 'Not found' } };
  }

  res.statusCode = response.status;
  res.setHeader('content-type', 'application/json');
  res.json(response.body);
}

export const config = {
  runtime: 'nodejs',
};
