/**
 * Supabase client, shared between the serverless API routes and the
 * local preview server (server.ts). Node-only — the credentials are
 * never shipped to the browser.
 *
 * Env:
 *   SUPABASE_URL            project url (e.g. https://<ref>.supabase.co)
 *   SUPABASE_SERVICE_ROLE_KEY  full-access service role key
 *   SUPABASE_ANON_KEY       client-side key (kept here only; proof it is
 *                           a Vercel secret and not accidentally readable by
 *                           any route. We never send it to the client in this
 *                           codebase, but we still avoid logging it.)
 */
import { createClient } from '@supabase/supabase-js';


let client: Awaited<ReturnType<typeof getClient>> | null = null;
let clientError: unknown | null = null;

function cleanUrl(raw: string): string {
  return raw?.replace(/\/+$/, '') ?? '';
}

/**
 * Returns a fresh Supabase client on each call. We intentionally do NOT
 * reuse a long-lived client because each serverless invocation is a single
 * request and a shared client would leak stale/stale-state and leak request
 * boundaries.
 */
export async function getClient(): Promise<ReturnType<typeof createClient>> {
  if (client) return client;

  const rawUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY ||
    process.env.SUPABASE_ANON_KEY ||
    process.env.VITE_SUPABASE_ANON_KEY;

  if (!rawUrl || !key) {
    const missing: string[] = [];
    if (!rawUrl) missing.push('SUPABASE_URL / VITE_SUPABASE_URL');
    if (!key) missing.push('SUPABASE_SERVICE_ROLE_KEY / SUPABASE_ANON_KEY');
    clientError = new Error(`Missing Supabase environment: ${missing.join(', ')}`);
    throw clientError;
  }

  const url = cleanUrl(rawUrl);

  client = createClient(url, key, {
    auth: { persistSession: false },
  });

  return client;
}

export function supabaseError(): unknown {
  return clientError;
}

export function clearSupabaseError(): void {
  clientError = null;
}
