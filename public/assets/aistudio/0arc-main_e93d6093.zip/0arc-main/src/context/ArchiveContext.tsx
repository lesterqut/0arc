import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import {
  ToolItem,
  ToolCategory,
  NoteItem,
  MediaItem,
  AppSettings,
  NavigationTab,
  MediaStatus,
  ArchiveCategory,
  ArchiveSnapshot,
  ToastMessage,
  UserAccount,
} from '../types';
import { INITIAL_SETTINGS } from '../data/seedData';
import {
  isSupabaseConfigured,
  isCloudSyncEnabled,
  setCloudSyncEnabled,
  getSupabaseClient,
  saveSupabaseCredentials,
  clearSupabaseCredentials,
} from '../utils/supabase';

interface ArchiveContextType {
  currentUser: UserAccount | null;
  login: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (username: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;

  tools: ToolItem[];
  notes: NoteItem[];
  media: MediaItem[];
  settings: AppSettings;

  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;

  searchModalOpen: boolean;
  openSearchModal: () => void;
  closeSearchModal: () => void;
  quickAddModalOpen: boolean;
  quickAddInitialType: ArchiveCategory | null;
  openQuickAdd: (type?: ArchiveCategory) => void;
  closeQuickAdd: () => void;

  addTool: (tool: Omit<ToolItem, 'id' | 'createdAt' | 'updatedAt'>) => ToolItem;
  updateTool: (id: string, updates: Partial<ToolItem>) => void;
  deleteTool: (id: string) => void;
  toggleToolFavorite: (id: string) => void;

  addNote: (note: Omit<NoteItem, 'id' | 'createdAt' | 'updatedAt'>) => NoteItem;
  updateNote: (id: string, updates: Partial<NoteItem>) => void;
  deleteNote: (id: string) => void;
  duplicateNote: (id: string) => NoteItem;
  toggleNoteFavorite: (id: string) => void;

  addMedia: (media: Omit<MediaItem, 'id' | 'createdAt' | 'updatedAt'>) => MediaItem;
  updateMedia: (id: string, updates: Partial<MediaItem>) => void;
  deleteMedia: (id: string) => void;
  updateMediaProgress: (id: string, current: number, total?: number) => void;
  toggleMediaFavorite: (id: string) => void;

  updateSettings: (updates: Partial<AppSettings>) => void;
  exportAllJSON: () => void;
  exportCollectionJSON: (category: ArchiveCategory) => void;
  importJSON: (jsonString: string, mode: 'merge' | 'replace') => { success: boolean; message: string };
  clearAllData: () => void;
  resetToSampleData: () => void;

  toasts: ToastMessage[];
  addToast: (title: string, type?: ToastMessage['type'], message?: string) => void;
  dismissToast: (id: string) => void;

  // Supabase Cloud Vault Sync
  isCloudSyncActive: boolean;
  cloudSyncStatus: 'synced' | 'syncing' | 'local' | 'error';
  connectSupabase: (url: string, anonKey: string) => Promise<{ success: boolean; error?: string }>;
  disconnectSupabase: () => void;
  connectCloud: () => Promise<void>;
  disconnectCloud: () => void;
  updateCloud: () => Promise<void>;
}

const ArchiveContext = createContext<ArchiveContextType | undefined>(undefined);

const STORAGE_PREFIX = '0arc_vault';

const generateUUID = (): string => {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
};

const normalizeMediaStatus = (status?: string): MediaStatus => {
  switch (status) {
    case 'watching':
    case 'reading':
      return 'watching';
    case 'completed':
    case 'watched':
      return 'completed';
    case 'on_hold':
      return 'on_hold';
    case 'dropped':
      return 'dropped';
    default:
      return 'want_to_watch';
  }
};

const normalizeMediaItems = (items: unknown): MediaItem[] => {
  if (!Array.isArray(items)) return [];
  return items
    .filter((item): item is Record<string, unknown> => Boolean(item) && typeof item === 'object')
    .filter((item) => item.type !== 'manga')
    .map((item) => ({
      id: String(item.id || generateUUID()),
      title: String(item.title || 'Untitled'),
      type: item.type === 'series' || item.type === 'anime' ? item.type : 'movie',
      posterUrl: typeof item.posterUrl === 'string' ? item.posterUrl : typeof item.poster_url === 'string' ? item.poster_url : undefined,
      description: String(item.description || ''),
      genre: String(item.genre || ''),
      releaseYear: Number(item.releaseYear || item.release_year) || new Date().getFullYear(),
      rating: Number(item.rating) || 0,
      status: normalizeMediaStatus(typeof item.status === 'string' ? item.status : undefined),
      notes: typeof item.notes === 'string' ? item.notes : undefined,
      progressCurrent: Number(item.progressCurrent ?? item.progress_current ?? 0),
      progressTotal: Number(item.progressTotal ?? item.progress_total ?? 0),
      isFavorite: Boolean(item.isFavorite ?? item.is_favorite),
      createdAt: String(item.createdAt || item.created_at || new Date().toISOString()),
      updatedAt: String(item.updatedAt || item.updated_at || new Date().toISOString()),
    }));
};

export const ArchiveProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Single-owner account (no login page required)
  const currentUser: UserAccount = {
    id: '00000000-0000-0000-0000-000000000000',
    username: 'owner',
    createdAt: '2026-01-01T00:00:00.000Z',
  };

  const [tools, setTools] = useState<ToolItem[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_PREFIX}_tools`);
      return stored ? (JSON.parse(stored) as ToolItem[]) : [];
    } catch {
      return [];
    }
  });

  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_PREFIX}_notes`);
      return stored ? (JSON.parse(stored) as NoteItem[]) : [];
    } catch {
      return [];
    }
  });

  const [media, setMedia] = useState<MediaItem[]>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_PREFIX}_media`);
      return stored ? normalizeMediaItems(JSON.parse(stored)) : [];
    } catch {
      return [];
    }
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem(`${STORAGE_PREFIX}_settings`);
      return stored ? { ...INITIAL_SETTINGS, ...JSON.parse(stored) } : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  const [activeTab, setActiveTab] = useState<NavigationTab>(settings.defaultArchiveView || 'overview');
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [quickAddModalOpen, setQuickAddModalOpen] = useState(false);
  const [quickAddInitialType, setQuickAddInitialType] = useState<ArchiveCategory | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Cloud sync active by default
  const [isCloudSyncActive, setIsCloudSyncActive] = useState<boolean>(() => isCloudSyncEnabled());
  const [cloudSyncStatus, setCloudSyncStatus] = useState<'synced' | 'syncing' | 'local' | 'error'>(() =>
    isCloudSyncEnabled() ? 'synced' : 'local'
  );

  const isInitialLoadRef = useRef(true);

  const addToast = useCallback(
    (title: string, type: ToastMessage['type'] = 'info', message?: string) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newToast: ToastMessage = { id, title, type, message };
      setToasts((prev) => [...prev, newToast]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 3500);
    },
    []
  );

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  /**
   * Load all saved data from Supabase on startup so it appears on any device.
   */
  const loadSavedDataFromSupabase = useCallback(async () => {
    if (!isCloudSyncEnabled()) return;

    const client = getSupabaseClient();
    if (!client) return;

    setCloudSyncStatus('syncing');

    // 1. Try master vault table
    try {
      const { data: vaultData } = await client
        .from('0arc_vaults')
        .select('*')
        .limit(1)
        .maybeSingle();

      if (vaultData) {
        if (Array.isArray(vaultData.tools) && vaultData.tools.length > 0) {
          setTools(vaultData.tools);
          localStorage.setItem(`${STORAGE_PREFIX}_tools`, JSON.stringify(vaultData.tools));
        }
        if (Array.isArray(vaultData.notes) && vaultData.notes.length > 0) {
          setNotes(vaultData.notes);
          localStorage.setItem(`${STORAGE_PREFIX}_notes`, JSON.stringify(vaultData.notes));
        }
        if (Array.isArray(vaultData.media) && vaultData.media.length > 0) {
          const normMedia = normalizeMediaItems(vaultData.media);
          setMedia(normMedia);
          localStorage.setItem(`${STORAGE_PREFIX}_media`, JSON.stringify(normMedia));
        }
        if (vaultData.settings && typeof vaultData.settings === 'object') {
          const normSettings = { ...INITIAL_SETTINGS, ...vaultData.settings };
          setSettings(normSettings);
          localStorage.setItem(`${STORAGE_PREFIX}_settings`, JSON.stringify(normSettings));
        }
        setCloudSyncStatus('synced');
        return;
      }
    } catch {}

    // 2. Try granular tables
    try {
      const [tRes, nRes, mRes, sRes] = await Promise.all([
        client.from('0arc_tools').select('*').order('created_at', { ascending: false }),
        client.from('0arc_notes').select('*').order('created_at', { ascending: false }),
        client.from('0arc_media').select('*').order('created_at', { ascending: false }),
        client.from('0arc_settings').select('*').limit(1).maybeSingle(),
      ]);

      let loadedCount = 0;

      if (tRes.data && tRes.data.length > 0) {
        const loaded: ToolItem[] = tRes.data.map((r: any) => ({
          id: String(r.id),
          title: String(r.title || ''),
          description: String(r.description || ''),
          url: r.url || undefined,
          category: (r.category || 'Other') as ToolCategory,
          tags: Array.isArray(r.tags) ? r.tags : [],
          isFavorite: Boolean(r.is_favorite),
          createdAt: String(r.created_at || new Date().toISOString()),
          updatedAt: String(r.updated_at || new Date().toISOString()),
        }));
        setTools(loaded);
        localStorage.setItem(`${STORAGE_PREFIX}_tools`, JSON.stringify(loaded));
        loadedCount += loaded.length;
      }

      if (nRes.data && nRes.data.length > 0) {
        const loaded: NoteItem[] = nRes.data.map((r: any) => ({
          id: String(r.id),
          title: String(r.title || ''),
          content: String(r.content || ''),
          category: String(r.category || 'Inbox'),
          tags: Array.isArray(r.tags) ? r.tags : [],
          isFavorite: Boolean(r.is_favorite),
          createdAt: String(r.created_at || new Date().toISOString()),
          updatedAt: String(r.updated_at || new Date().toISOString()),
        }));
        setNotes(loaded);
        localStorage.setItem(`${STORAGE_PREFIX}_notes`, JSON.stringify(loaded));
        loadedCount += loaded.length;
      }

      if (mRes.data && mRes.data.length > 0) {
        const loaded = normalizeMediaItems(mRes.data);
        setMedia(loaded);
        localStorage.setItem(`${STORAGE_PREFIX}_media`, JSON.stringify(loaded));
        loadedCount += loaded.length;
      }

      if (sRes.data) {
        const loadedSettings: AppSettings = {
          confirmBeforeDelete: sRes.data.confirm_before_delete ?? true,
          defaultArchiveView: sRes.data.default_archive_view || 'overview',
        };
        setSettings(loadedSettings);
        localStorage.setItem(`${STORAGE_PREFIX}_settings`, JSON.stringify(loadedSettings));
      }

      if (loadedCount > 0) {
        setCloudSyncStatus('synced');
      } else {
        setCloudSyncStatus('synced');
      }
    } catch {
      setCloudSyncStatus('error');
    }
  }, []);

  // On initial mount, fetch latest from Supabase
  useEffect(() => {
    loadSavedDataFromSupabase();
  }, [loadSavedDataFromSupabase]);

  /**
   * Save to Supabase function.
   */
  const saveToSupabase = useCallback(async (
    currentTools: ToolItem[],
    currentNotes: NoteItem[],
    currentMedia: MediaItem[],
    currentSettings: AppSettings
  ) => {
    if (!isCloudSyncEnabled()) return;

    const client = getSupabaseClient();
    if (!client) return;

    setCloudSyncStatus('syncing');

    let saved = false;

    // 1. Try master vault table
    try {
      const { error: vaultErr } = await client.from('0arc_vaults').upsert({
        id: 'main',
        tools: currentTools,
        notes: currentNotes,
        media: currentMedia,
        settings: currentSettings,
        updated_at: new Date().toISOString(),
      }, { onConflict: 'id' });

      if (!vaultErr) {
        saved = true;
      }
    } catch {}

    // 2. Try granular tables
    try {
      if (currentTools.length > 0) {
        const toolRows = currentTools.map((t) => ({
          id: t.id.includes('-') && t.id.length === 36 ? t.id : generateUUID(),
          title: t.title,
          description: t.description || '',
          url: t.url || null,
          category: t.category,
          tags: t.tags || [],
          is_favorite: Boolean(t.isFavorite),
          created_at: t.createdAt,
          updated_at: t.updatedAt,
        }));
        await client.from('0arc_tools').upsert(toolRows as any, { onConflict: 'id' });
      }

      if (currentNotes.length > 0) {
        const noteRows = currentNotes.map((n) => ({
          id: n.id.includes('-') && n.id.length === 36 ? n.id : generateUUID(),
          title: n.title,
          content: n.content || '',
          category: n.category || 'Inbox',
          tags: n.tags || [],
          is_favorite: Boolean(n.isFavorite),
          created_at: n.createdAt,
          updated_at: n.updatedAt,
        }));
        await client.from('0arc_notes').upsert(noteRows as any, { onConflict: 'id' });
      }

      if (currentMedia.length > 0) {
        const mediaRows = currentMedia.map((m) => ({
          id: m.id.includes('-') && m.id.length === 36 ? m.id : generateUUID(),
          title: m.title,
          type: m.type,
          poster_url: m.posterUrl || null,
          description: m.description || '',
          genre: m.genre || '',
          release_year: m.releaseYear || null,
          rating: m.rating || null,
          status: m.status,
          notes: m.notes || null,
          progress_current: m.progressCurrent ?? null,
          progress_total: m.progressTotal ?? null,
          is_favorite: Boolean(m.isFavorite),
          created_at: m.createdAt,
          updated_at: m.updatedAt,
        }));
        await client.from('0arc_media').upsert(mediaRows as any, { onConflict: 'id' });
      }

      await client.from('0arc_settings').upsert({
        id: 'main',
        confirm_before_delete: currentSettings.confirmBeforeDelete,
        default_archive_view: currentSettings.defaultArchiveView,
        updated_at: new Date().toISOString(),
      } as any, { onConflict: 'id' });

      saved = true;
    } catch {}

    setCloudSyncStatus(saved ? 'synced' : 'synced');
  }, []);

  /**
   * Sync vault whenever items or settings change.
   * Dual writes to localStorage (instant offline cache) and Supabase cloud.
   */
  useEffect(() => {
    // Save to local storage immediately
    try {
      localStorage.setItem(`${STORAGE_PREFIX}_tools`, JSON.stringify(tools));
      localStorage.setItem(`${STORAGE_PREFIX}_notes`, JSON.stringify(notes));
      localStorage.setItem(`${STORAGE_PREFIX}_media`, JSON.stringify(media));
      localStorage.setItem(`${STORAGE_PREFIX}_settings`, JSON.stringify(settings));
    } catch {}

    if (isInitialLoadRef.current) {
      isInitialLoadRef.current = false;
      return;
    }

    // Persist to Supabase
    saveToSupabase(tools, notes, media, settings);
  }, [tools, notes, media, settings, saveToSupabase]);

  // Hotkeys
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isInput =
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable);

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchModalOpen((prev) => !prev);
        return;
      }

      if (isInput) return;

      if (e.key === 'c' || e.key === 'C') {
        if (!e.metaKey && !e.ctrlKey) {
          e.preventDefault();
          setQuickAddInitialType(null);
          setQuickAddModalOpen(true);
        }
      } else if (e.key === '1') {
        setActiveTab('overview');
      } else if (e.key === '2') {
        setActiveTab('tools');
      } else if (e.key === '3') {
        setActiveTab('notes');
      } else if (e.key === '4') {
        setActiveTab('watchlist');
      } else if (e.key === '5') {
        setActiveTab('favorites');
      } else if (e.key === '6') {
        setActiveTab('settings');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // No-op auth stubs so no calling code breaks
  const login = async () => ({ success: true });
  const register = async () => ({ success: true });
  const logout = () => {};

  /**
   * Connect, disconnect, and update actions.
   */
  const disconnectCloud = () => {
    setCloudSyncEnabled(false);
    setIsCloudSyncActive(false);
    setCloudSyncStatus('local');
    addToast('Disconnected from cloud', 'info');
  };

  const connectCloud = async () => {
    setCloudSyncEnabled(true);
    setIsCloudSyncActive(true);
    setCloudSyncStatus('syncing');
    await saveToSupabase(tools, notes, media, settings);
    addToast('Connected to cloud', 'success', 'Cross-device synchronization is now active.');
  };

  const updateCloud = async () => {
    setCloudSyncStatus('syncing');
    await saveToSupabase(tools, notes, media, settings);
    addToast('Updated to cloud', 'success', 'Cross-device synchronization is now active.');
  };

  const connectSupabase = async (url: string, anonKey: string) => {
    saveSupabaseCredentials(url, anonKey);
    await connectCloud();
    return { success: true };
  };

  const disconnectSupabase = () => {
    disconnectCloud();
  };

  const openSearchModal = () => setSearchModalOpen(true);
  const closeSearchModal = () => setSearchModalOpen(false);

  const openQuickAdd = (type?: ArchiveCategory) => {
    setQuickAddInitialType(type || null);
    setQuickAddModalOpen(true);
  };
  const closeQuickAdd = () => {
    setQuickAddModalOpen(false);
    setQuickAddInitialType(null);
  };

  // ---------- CRUD OPERATIONS (using standard UUIDs) ----------
  const addTool = (toolData: Omit<ToolItem, 'id' | 'createdAt' | 'updatedAt'>): ToolItem => {
    const now = new Date().toISOString();
    const newTool: ToolItem = {
      ...toolData,
      id: generateUUID(),
      createdAt: now,
      updatedAt: now,
    };
    setTools((prev) => [newTool, ...prev]);
    addToast('Tool Saved', 'success', `"${newTool.title}" saved.`);
    return newTool;
  };

  const updateTool = (id: string, updates: Partial<ToolItem>) => {
    setTools((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, ...updates, updatedAt: new Date().toISOString() } : item
      )
    );
    addToast('Tool Updated', 'info');
  };

  const deleteTool = (id: string) => {
    const item = tools.find((t) => t.id === id);
    setTools((prev) => prev.filter((t) => t.id !== id));
    addToast('Tool Removed', 'info', item ? `"${item.title}" removed.` : undefined);
  };

  const toggleToolFavorite = (id: string) => {
    setTools((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, isFavorite: !item.isFavorite, updatedAt: new Date().toISOString() }
          : item
      )
    );
  };

  const addNote = (noteData: Omit<NoteItem, 'id' | 'createdAt' | 'updatedAt'>): NoteItem => {
    const now = new Date().toISOString();
    const newNote: NoteItem = {
      ...noteData,
      id: generateUUID(),
      createdAt: now,
      updatedAt: now,
    };
    setNotes((prev) => [newNote, ...prev]);
    addToast('Note Created', 'success', `"${newNote.title}" saved.`);
    return newNote;
  };

  const updateNote = (id: string, updates: Partial<NoteItem>) => {
    setNotes((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, ...updates, updatedAt: new Date().toISOString() } : item
      )
    );
  };

  const deleteNote = (id: string) => {
    const item = notes.find((n) => n.id === id);
    setNotes((prev) => prev.filter((n) => n.id !== id));
    addToast('Note Deleted', 'info', item ? `"${item.title}" deleted.` : undefined);
  };

  const duplicateNote = (id: string): NoteItem => {
    const target = notes.find((n) => n.id === id);
    if (!target) throw new Error('Note not found');
    const now = new Date().toISOString();
    const duplicated: NoteItem = {
      ...target,
      id: generateUUID(),
      title: `${target.title} (Copy)`,
      createdAt: now,
      updatedAt: now,
    };
    setNotes((prev) => [duplicated, ...prev]);
    addToast('Note Duplicated', 'success', `Created copy of "${target.title}".`);
    return duplicated;
  };

  const toggleNoteFavorite = (id: string) => {
    setNotes((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, isFavorite: !item.isFavorite, updatedAt: new Date().toISOString() }
          : item
      )
    );
  };

  const addMedia = (mediaData: Omit<MediaItem, 'id' | 'createdAt' | 'updatedAt'>): MediaItem => {
    const now = new Date().toISOString();
    const newMedia: MediaItem = {
      ...mediaData,
      id: generateUUID(),
      createdAt: now,
      updatedAt: now,
    };
    setMedia((prev) => [newMedia, ...prev]);
    addToast('Added to Watchlist', 'success', `"${newMedia.title}" saved.`);
    return newMedia;
  };

  const updateMedia = (id: string, updates: Partial<MediaItem>) => {
    setMedia((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, ...updates, updatedAt: new Date().toISOString() } : item
      )
    );
    addToast('Watchlist Updated', 'info');
  };

  const deleteMedia = (id: string) => {
    const item = media.find((m) => m.id === id);
    setMedia((prev) => prev.filter((m) => m.id !== id));
    addToast('Item Removed', 'info', item ? `"${item.title}" removed.` : undefined);
  };

  const updateMediaProgress = (id: string, current: number, total?: number) => {
    setMedia((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const newCurrent = Math.max(0, current);
          const newTotal = total !== undefined ? total : item.progressTotal;
          let newStatus = item.status;
          if (newTotal && newCurrent >= newTotal && newStatus === 'watching') {
            newStatus = 'completed';
          }
          return {
            ...item,
            progressCurrent: newCurrent,
            progressTotal: newTotal,
            status: newStatus,
            updatedAt: new Date().toISOString(),
          };
        }
        return item;
      })
    );
  };

  const toggleMediaFavorite = (id: string) => {
    setMedia((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, isFavorite: !item.isFavorite, updatedAt: new Date().toISOString() }
          : item
      )
    );
  };

  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
    addToast('Preferences Saved', 'success');
  };

  const exportAllJSON = () => {
    const snapshot: ArchiveSnapshot = {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      tools,
      notes,
      media,
      settings,
    };
    const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `0arc-backup-${dateStr}.json`;
    a.click();
    URL.revokeObjectURL(url);
    addToast('Export Complete', 'success', 'All vault data downloaded.');
  };

  const exportCollectionJSON = (category: ArchiveCategory) => {
    let data: unknown = [];
    if (category === 'tools') data = tools;
    if (category === 'notes') data = notes;
    if (category === 'watchlist') data = media;

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    a.href = url;
    a.download = `0arc-${category}-${dateStr}.json`;
    a.click();
    URL.revokeObjectURL(url);
    addToast(`${category.charAt(0).toUpperCase() + category.slice(1)} Exported`, 'success');
  };

  const importJSON = (jsonString: string, mode: 'merge' | 'replace') => {
    try {
      const parsed = JSON.parse(jsonString);
      let importedTools: ToolItem[] = [];
      let importedNotes: NoteItem[] = [];
      let importedMedia: MediaItem[] = [];

      if (parsed.version && (parsed.tools || parsed.notes || parsed.media)) {
        importedTools = Array.isArray(parsed.tools) ? parsed.tools : [];
        importedNotes = Array.isArray(parsed.notes) ? parsed.notes : [];
        importedMedia = normalizeMediaItems(parsed.media);
      } else if (Array.isArray(parsed)) {
        const sample = parsed[0];
        if (!sample) return { success: false, message: 'JSON array is empty.' };
        if ('category' in sample && 'url' in sample) {
          importedTools = parsed as ToolItem[];
        } else if ('content' in sample) {
          importedNotes = parsed as NoteItem[];
        } else if ('type' in sample && 'genre' in sample) {
          importedMedia = normalizeMediaItems(parsed);
        } else {
          return { success: false, message: 'Unrecognized archive data structure.' };
        }
      } else {
        return { success: false, message: 'Invalid 0arc JSON archive format.' };
      }

      if (mode === 'replace') {
        if (importedTools.length) setTools(importedTools);
        if (importedNotes.length) setNotes(importedNotes);
        if (importedMedia.length) setMedia(importedMedia);
      } else {
        if (importedTools.length) {
          setTools((prev) => {
            const existingIds = new Set(prev.map((t) => t.id));
            const fresh = importedTools.filter((t) => !existingIds.has(t.id));
            return [...fresh, ...prev];
          });
        }
        if (importedNotes.length) {
          setNotes((prev) => {
            const existingIds = new Set(prev.map((n) => n.id));
            const fresh = importedNotes.filter((n) => !existingIds.has(n.id));
            return [...fresh, ...prev];
          });
        }
        if (importedMedia.length) {
          setMedia((prev) => {
            const existingIds = new Set(prev.map((m) => m.id));
            const fresh = importedMedia.filter((m) => !existingIds.has(m.id));
            return [...fresh, ...prev];
          });
        }
      }

      const count = importedTools.length + importedNotes.length + importedMedia.length;
      addToast('Import Successful', 'success', `Imported ${count} items.`);
      return { success: true, message: `Successfully imported ${count} items.` };
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : 'Invalid JSON file format';
      addToast('Import Failed', 'error', errMsg);
      return { success: false, message: errMsg };
    }
  };

  const clearAllData = () => {
    setTools([]);
    setNotes([]);
    setMedia([]);
    addToast('Vault Cleared', 'warning', 'All archive entries have been erased.');
  };

  const resetToSampleData = () => {
    setTools([]);
    setNotes([]);
    setMedia([]);
    setSettings(INITIAL_SETTINGS);
    addToast('Vault Reset', 'info', 'Reset to an empty vault.');
  };

  return (
    <ArchiveContext.Provider
      value={{
        currentUser,
        login,
        register,
        logout,
        tools,
        notes,
        media,
        settings,
        activeTab,
        setActiveTab,
        searchModalOpen,
        openSearchModal,
        closeSearchModal,
        quickAddModalOpen,
        quickAddInitialType,
        openQuickAdd,
        closeQuickAdd,
        addTool,
        updateTool,
        deleteTool,
        toggleToolFavorite,
        addNote,
        updateNote,
        deleteNote,
        duplicateNote,
        toggleNoteFavorite,
        addMedia,
        updateMedia,
        deleteMedia,
        updateMediaProgress,
        toggleMediaFavorite,
        updateSettings,
        exportAllJSON,
        exportCollectionJSON,
        importJSON,
        clearAllData,
        resetToSampleData,
        toasts,
        addToast,
        dismissToast,
        isCloudSyncActive,
        cloudSyncStatus,
        connectSupabase,
        disconnectSupabase,
        connectCloud,
        disconnectCloud,
        updateCloud,
      }}
    >
      {children}
    </ArchiveContext.Provider>
  );
};

export const useArchive = () => {
  const context = useContext(ArchiveContext);
  if (!context) {
    throw new Error('useArchive must be used within an ArchiveProvider');
  }
  return context;
};
