import { ToolItem, NoteItem, MediaItem, AppSettings } from '../types';

export const INITIAL_SETTINGS: AppSettings = {
  confirmBeforeDelete: true,
  defaultArchiveView: 'overview',
};

export const SEED_TOOLS: ToolItem[] = [];
/*
 * SEED_TOOLS used to export a curated sample vault. It is now an empty array
 * so new accounts start blank; the user can add their own items.
 *
 * If you ever want the sample vault back, swap this empty array back to the
 * original list and restore the seed fallback in the vault loaders, login,
 * register, and logout paths.
 */
export const SEED_TOOLS_BACKCOMPAT: ToolItem[] = [
  {
    id: 'tool-raycast',
    title: 'Raycast',
    description: 'An extendable launcher that replaces Spotlight with supercharged command workflows, window management, and custom scripts.',
    url: 'https://raycast.com',
    category: 'Productivity',
    tags: ['launcher', 'macos', 'hotkeys', 'shortcuts'],
    isFavorite: true,
    createdAt: '2026-02-14T10:15:00.000Z',
    updatedAt: '2026-02-14T10:15:00.000Z',
  },
  {
    id: 'tool-linear',
    title: 'Linear',
    description: 'The benchmark for issue tracking, streamlined project roadmaps, and keyboard-first developer interfaces.',
    url: 'https://linear.app',
    category: 'Productivity',
    tags: ['project-management', 'ui-benchmark', 'issue-tracking'],
    isFavorite: true,
    createdAt: '2026-02-10T14:20:00.000Z',
    updatedAt: '2026-02-10T14:20:00.000Z',
  },
  {
    id: 'tool-cursor',
    title: 'Cursor',
    description: 'AI-first code editor built on VS Code with codebase-wide indexing, instant multi-file diffing, and fast terminal completions.',
    url: 'https://cursor.com',
    category: 'Development',
    tags: ['editor', 'ai', 'developer-tools'],
    isFavorite: true,
    createdAt: '2026-02-05T09:40:00.000Z',
    updatedAt: '2026-02-05T09:40:00.000Z',
  },
  {
    id: 'tool-excalidraw',
    title: 'Excalidraw',
    description: 'Virtual collaborative whiteboard with a hand-drawn feel, end-to-end encryption, and SVG export capabilities.',
    url: 'https://excalidraw.com',
    category: 'Design',
    tags: ['whiteboard', 'diagrams', 'collaboration', 'svg'],
    isFavorite: false,
    createdAt: '2026-01-22T16:00:00.000Z',
    updatedAt: '2026-01-22T16:00:00.000Z',
  },
  {
    id: 'tool-supabase',
    title: 'Supabase',
    description: 'Open source Firebase alternative providing a dedicated PostgreSQL database, authentication, instant APIs, and edge functions.',
    url: 'https://supabase.com',
    category: 'Development',
    tags: ['database', 'postgres', 'backend', 'open-source'],
    isFavorite: true,
    createdAt: '2026-01-18T11:10:00.000Z',
    updatedAt: '2026-01-18T11:10:00.000Z',
  },
  {
    id: 'tool-tailwind',
    title: 'Tailwind CSS Play',
    description: 'Instant browser playground for prototyping utility-first Tailwind layouts with configuration tweaks.',
    url: 'https://play.tailwindcss.com',
    category: 'Websites',
    tags: ['css', 'styling', 'frontend', 'sandbox'],
    isFavorite: false,
    createdAt: '2026-01-12T08:30:00.000Z',
    updatedAt: '2026-01-12T08:30:00.000Z',
  },
  {
    id: 'tool-readwise',
    title: 'Readwise Reader',
    description: 'All-in-one read-later app tailored for web articles, newsletters, PDFs, and EPUBs with bidirectional highlight sync.',
    url: 'https://readwise.io/read',
    category: 'Learning',
    tags: ['reading', 'pkm', 'highlights', 'articles'],
    isFavorite: true,
    createdAt: '2026-01-05T19:00:00.000Z',
    updatedAt: '2026-01-05T19:00:00.000Z',
  },
];

export const SEED_NOTES: NoteItem[] = [];
/*
 * SEED_NOTES used to export a curated sample vault. It is now an empty array
 * so new accounts start blank.
 */
export const SEED_NOTES_BACKCOMPAT: NoteItem[] = [
  {
    id: 'note-local-first',
    title: 'Local-First Architecture & Design Principles',
    category: 'Engineering',
    tags: ['architecture', 'local-first', 'crdt', 'offline'],
    isFavorite: true,
    content: `## The Core Thesis
Software should feel instantaneous and belong to the user. Local-first software prioritizes local persistence first, with cloud synchronization acting as an asynchronous secondary layer.

### Seven Principles:
1. **No spinners for basic work**: Reading, editing, and navigating must happen with sub-millisecond local latency.
2. **Multi-device sync**: Changes propagate peer-to-peer or via light sync relays.
3. **Network is optional**: Full offline capability by default.
4. **Seamless collaboration**: Conflict-free resolution through CRDTs or deterministic operational transformation.
5. **Data longevity**: Plain formats (JSON, SQLite, Markdown) that outlive any SaaS company.
6. **User owns their data**: Readily exportable, portable, inspectable.
7. **Security and privacy by default**: Encryption at rest and in transit.

> "Your computer should be your archive, not just a thin terminal into somebody else's server."`,
    createdAt: '2026-02-12T14:00:00.000Z',
    updatedAt: '2026-02-15T09:30:00.000Z',
  },
  {
    id: 'note-dark-ui',
    title: 'Visual System Heuristics for Dark Interfaces',
    category: 'Design',
    tags: ['design-system', 'dark-mode', 'typography', 'contrast'],
    isFavorite: true,
    content: `## Principles of Restrained Dark Design

### 1. The 60-30-10 Surface Rule
- **60% Dominant Neutral Canvas**: #09090B deep obsidian base.
- **30% Structural Surfaces**: #0D0D10 sidebar, #121216 cards, #18181D elevated panels.
- **10% Accent Budget**: Crisp white and warm amber accents reserved for active focal points and star ratings.

### 2. Optical Weight Compensation
Light typography on pitch-black surfaces tends to look thinner than on white. Always give small text 0.01em wider tracking and keep font weights between 450-550 for maximum readability.

### 3. Hairlines over Heavy Shadows
In dark interfaces, cast drop shadows are barely visible. Rely on 1px subtle borders (#27272A or rgba(255,255,255,0.08)) with a soft inset highlight.`,
    createdAt: '2026-02-08T18:15:00.000Z',
    updatedAt: '2026-02-11T20:10:00.000Z',
  },
  {
    id: 'note-weekly-checklist',
    title: 'Weekly Focus & Deep Work Rituals',
    category: 'Productivity',
    tags: ['rituals', 'deep-work', 'habits', 'weekly'],
    isFavorite: false,
    content: `## Monday Calibration
[x] Clear inbox and triage urgent async messages
[x] Define 3 core milestones for the week
[ ] Review open pull requests and architecture specs
[ ] Schedule 3 uninterrupted morning deep work blocks (08:30 - 12:00)

## Daily Discipline
- Zero notifications on mobile during focus sprints.
- Capture fleeting ideas directly into 0arc inbox rather than leaving browser tabs open.
- Wind down at 18:00 with brief log of accomplishments.`,
    createdAt: '2026-02-01T08:00:00.000Z',
    updatedAt: '2026-02-14T17:45:00.000Z',
  },
  {
    id: 'note-reading-essays',
    title: 'Core Essays & Papers Worth Re-Reading',
    category: 'Reading',
    tags: ['essays', 'computer-science', 'philosophy'],
    isFavorite: false,
    content: `### High-Priority Readings
1. **As We May Think** — Vannevar Bush (1945)
   - Foundation of the Memex concept; early blueprint for modern personal archives and hypertext.
2. **The Humble Programmer** — Edsger W. Dijkstra (1972)
   - Intellectual limitations of the human mind and why software architecture must remain radically simple.
3. **Worse Is Better** — Richard P. Gabriel
   - Why simplicity of implementation frequently defeats purist perfection.
4. **Augmenting Human Intellect** — Douglas Engelbart
   - Framing computing as external cognitive scaffolding.`,
    createdAt: '2026-01-20T11:00:00.000Z',
    updatedAt: '2026-01-20T11:00:00.000Z',
  },
];

export const SEED_MEDIA: MediaItem[] = [];
/*
 * SEED_MEDIA used to export a curated sample vault. It is now an empty array
 * so new accounts start blank.
 */
export const SEED_MEDIA_BACKCOMPAT: MediaItem[] = [
  {
    id: 'media-blade-runner-2049',
    title: 'Blade Runner 2049',
    type: 'movie',
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    description: 'Officer K, a new blade runner for the Los Angeles Police Department, unearths a long-buried secret that has the potential to plunge what is left of society into chaos.',
    genre: 'Sci-Fi / Neo-Noir',
    releaseYear: 2017,
    rating: 10,
    status: 'completed',
    notes: 'Roger Deakins cinematography is unmatched. The scale and brutalist industrial architecture create an unmatched atmosphere.',
    isFavorite: true,
    createdAt: '2026-01-10T12:00:00.000Z',
    updatedAt: '2026-01-10T12:00:00.000Z',
  },
  {
    id: 'media-severance',
    title: 'Severance',
    type: 'series',
    posterUrl: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=80',
    description: 'Mark leads a team of office workers whose memories have been surgically divided between their work and personal lives. When a mysterious colleague appears outside of work, it begins a journey to discover the truth.',
    genre: 'Psychological Thriller',
    releaseYear: 2022,
    rating: 10,
    status: 'watching',
    notes: 'Brilliant corporate satire turned existential mystery. Waiting for Season 2 finale.',
    progressCurrent: 9,
    progressTotal: 10,
    isFavorite: true,
    createdAt: '2026-02-02T15:00:00.000Z',
    updatedAt: '2026-02-14T19:30:00.000Z',
  },
  {
    id: 'media-frieren',
    title: 'Frieren: Beyond Journey’s End',
    type: 'anime',
    posterUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
    description: 'An elf mage and her fellow adventurers have defeated the Demon King, bringing peace to the land. But as an elf who lives for centuries, she grapples with the fleeting mortality of her human companions.',
    genre: 'Fantasy / Melancholy',
    releaseYear: 2023,
    rating: 10,
    status: 'watching',
    notes: 'The depiction of time, grief, and quiet human connections is sublime. Beautiful pacing and battle choreography.',
    progressCurrent: 24,
    progressTotal: 28,
    isFavorite: true,
    createdAt: '2026-01-15T21:00:00.000Z',
    updatedAt: '2026-02-12T22:15:00.000Z',
  },
  {
    id: 'media-dune-2',
    title: 'Dune: Part Two',
    type: 'movie',
    posterUrl: 'https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?w=600&auto=format&fit=crop&q=80',
    description: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.',
    genre: 'Sci-Fi / Epic',
    releaseYear: 2024,
    rating: 9,
    status: 'completed',
    notes: 'Masterclass in sound design and monumental scale. Giedi Prime monochromatic arena sequence is unforgettable.',
    isFavorite: false,
    createdAt: '2026-01-14T20:00:00.000Z',
    updatedAt: '2026-01-14T20:00:00.000Z',
  },
  {
    id: 'media-arcane',
    title: 'Arcane',
    type: 'series',
    posterUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&auto=format&fit=crop&q=80',
    description: 'Set in the utopian Piltover and the oppressed underground of Zaun, the story follows the origins of two iconic League champions-and the power that will tear them apart.',
    genre: 'Animation / Steampunk',
    releaseYear: 2021,
    rating: 10,
    status: 'completed',
    notes: 'Fortiche Production transformed television animation forever. Phenomenal character arcs and music integration.',
    progressCurrent: 18,
    progressTotal: 18,
    isFavorite: true,
    createdAt: '2026-01-02T19:00:00.000Z',
    updatedAt: '2026-01-20T15:00:00.000Z',
  },
  {
    id: 'media-past-lives',
    title: 'Past Lives',
    type: 'movie',
    posterUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=600&auto=format&fit=crop&q=80',
    description: 'Nora and Hae Sung, two deeply connected childhood friends, are wrested apart after Nora\'s family emigrates from South Korea. Two decades later, they are reunited in New York for one fateful week.',
    genre: 'Drama / Romance',
    releaseYear: 2023,
    rating: 9,
    status: 'want_to_watch',
    notes: 'Explores the concept of In-Yun (fate/destiny in Korean philosophy). Highly recommended by multiple critics.',
    isFavorite: false,
    createdAt: '2026-02-01T12:00:00.000Z',
    updatedAt: '2026-02-01T12:00:00.000Z',
  },
];


