/**
 * Free movie / TV lookup that runs entirely in the browser.
 *
 * Everything here is keyless and CORS-enabled, so it works the same in the
 * local preview server and in the static production build (which has no
 * server-side /api routes).
 *
 * Sources, in order:
 *   1. Cinemeta (Stremio's free IMDb metadata API): search + exact details,
 *      including the real IMDb rating, genres, synopsis and poster.
 *   2. TVMaze (free, no key): richer episode/show details and posters.
 *   3. Wikipedia REST summary (free, no key): synopsis + infobox image.
 */
import type { MediaType } from '../types';

export interface MediaCandidate {
  /** IMDb id, e.g. tt1375666. */
  id: string;
  title: string;
  year?: number;
  type: MediaType;
  rawType?: string;
  posterUrl?: string;
  stars?: string;
}

export interface MediaDetails {
  title: string;
  type: MediaType;
  description: string;
  genre: string;
  releaseYear: number;
  rating: number;
  posterUrl: string;
}

const CINEMETA_BASE = 'https://v3-cinemeta.strem.io';
const REQUEST_TIMEOUT_MS = 7000;

interface CinemetaMeta {
  id?: string;
  imdb_id?: string;
  type?: string;
  name?: string;
  poster?: string;
  background?: string;
  releaseInfo?: string;
  year?: string;
  description?: string;
  genre?: string[];
  genres?: string[];
  imdbRating?: string;
  cast?: string[];
}

interface TvmazeShow {
  name?: string;
  summary?: string;
  premiered?: string;
  genres?: string[];
  rating?: { average?: number | null };
  image?: { medium?: string; original?: string };
}

interface WikiSummary {
  extract?: string;
  description?: string;
  originalimage?: { source?: string };
  thumbnail?: { source?: string };
}

async function fetchJson<T>(url: string): Promise<T | null> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Return the best available poster URL for a Cinemeta/IMDb image.
 *
 * Cinemeta returns posters from more than one host:
 *   - images.metahub.space/poster/small/<id>/img
 *   - m.media-amazon.com/..._V1_SX250.jpg (and similar)
 *
 * We upgrade those to the sharpest version we can reliably load, and cache
 * the result so the same poster is not re-resolved on every render.
 */
const posterCache = new Map<string, string | undefined>();

function bestPosterUrl(url?: string, imdbId?: string): string | undefined {
  if (!url && !imdbId) return undefined;

  const cacheKey = url ?? `imdb:${imdbId}`;
  const cached = posterCache.get(cacheKey);
  if (cached !== undefined) return cached;

  let upgraded: string | undefined;

  if (url) {
    // MetaHub: single reliable upgrade path, small -> medium.
    if (url.includes('images.metahub.space/poster/small/')) {
      upgraded = url.replace('/poster/small/', '/poster/medium/');
    } else if (url.includes('m.media-amazon.com')) {
      // Amazon posters are usually SX250 by default. Best-effort upgrade to a
      // larger UX variant, but do it without slowing down the render with an
      // async probe. If this ever becomes async, sync callers must `await` it.
      upgraded = url.replace(/(\._V1_(?:SX|UX|SY|UY))\d+/, '$1600');
    } else {
      upgraded = url;
    }
  } else if (imdbId && /^tt\d+$/.test(imdbId)) {
    upgraded = `https://images.metahub.space/poster/medium/${imdbId}/img`;
  }

  posterCache.set(cacheKey, upgraded);
  return upgraded;
}


function yearFrom(value?: string): number | undefined {
  const match = /(\d{4})/.exec(value || '');
  return match ? Number(match[1]) : undefined;
}

function stripHtml(value?: string): string {
  return (value || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function normalize(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function kindLabel(kind: 'movie' | 'series'): string {
  return kind === 'series' ? 'TV Series' : 'Movie';
}

const searchCache = new Map<string, MediaCandidate[]>();

/**
 * Search movies and shows at once, ranked so the closest title match wins.
 * Cinemeta search is loose ("the office" also returns unrelated movies), so
 * exact / prefix matches are pushed to the top.
 */
export async function searchMedia(
  query: string,
  requestedType?: MediaType,
): Promise<MediaCandidate[]> {
  const clean = query.trim();
  if (clean.length < 2) return [];

  const cacheKey = `${requestedType || 'any'}:${clean.toLowerCase()}`;
  const cached = searchCache.get(cacheKey);
  if (cached) return cached;

  const [movieRes, seriesRes] = await Promise.all([
    fetchJson<{ metas?: CinemetaMeta[] }>(
      `${CINEMETA_BASE}/catalog/movie/top/search=${encodeURIComponent(clean)}.json`,
    ),
    fetchJson<{ metas?: CinemetaMeta[] }>(
      `${CINEMETA_BASE}/catalog/series/top/search=${encodeURIComponent(clean)}.json`,
    ),
  ]);

  const pools: Array<{ kind: 'movie' | 'series'; metas: CinemetaMeta[] }> = [
    { kind: 'movie', metas: movieRes?.metas ?? [] },
    { kind: 'series', metas: seriesRes?.metas ?? [] },
  ];

  const normQuery = normalize(clean);
  const seen = new Set<string>();
  const ranked: Array<{ candidate: MediaCandidate; score: number }> = [];

  for (const pool of pools) {
    pool.metas.forEach((meta, index) => {
      const id = meta.imdb_id || meta.id || '';
      if (!/^tt\d+$/.test(id) || seen.has(id)) return;
      const title = (meta.name || '').trim();
      if (!title) return;
      seen.add(id);

      const normTitle = normalize(title);
      let score = 10;
      if (normTitle === normQuery) score = 100;
      else if (normTitle.startsWith(normQuery)) score = 70;
      else if (normTitle.includes(normQuery)) score = 45;

      if (requestedType === 'movie' && pool.kind === 'movie') score += 4;
      if (requestedType === 'series' && pool.kind === 'series') score += 4;
      if (requestedType === 'anime' && pool.kind === 'series') score += 4;
      score -= index * 0.5;

      ranked.push({
        score,
        candidate: {
          id,
          title,
          year: yearFrom(meta.releaseInfo) ?? yearFrom(meta.year),
          type: requestedType === 'anime' ? 'anime' : pool.kind === 'series' ? 'series' : 'movie',
          rawType: kindLabel(pool.kind),
          posterUrl: bestPosterUrl(meta.poster, id),
        },
      });
    });
  }

  const sorted = ranked.sort((a, b) => b.score - a.score);
  // Drop the filler Cinemeta sometimes appends ("Rebel Moon" for "Dune Part Two")
  // whenever there is at least one genuinely relevant title.
  const relevant = sorted.filter((entry) => entry.score >= 20);
  const results = (relevant.length ? relevant : sorted)
    .slice(0, 8)
    .map((entry) => ({
      ...entry.candidate,
      posterUrl: bestPosterUrl(entry.candidate.posterUrl),
    }));

  if (results.length) searchCache.set(cacheKey, results);
  return results;
}

async function wikipediaSummary(
  title: string,
  type: MediaType,
): Promise<{ extract: string; image?: string; year?: number } | null> {
  const variants =
    type === 'movie'
      ? [`${title} (film)`, title]
      : [`${title} (TV series)`, title, `${title} (TV series)`];

  for (const variant of variants) {
    const page = encodeURIComponent(variant.replace(/ /g, '_'));
    const data = await fetchJson<WikiSummary>(
      `https://en.wikipedia.org/api/rest_v1/page/summary/${page}?redirect=true`,
    );
    if (!data?.extract || /may refer to/.test(data.extract)) continue;
    return {
      extract: data.extract,
      image: data.originalimage?.source || data.thumbnail?.source,
      year: yearFrom(data.description) ?? yearFrom(data.extract),
    };
  }
  return null;
}

/**
 * Resolve the full record for one title. Pass an IMDb id when the user picked
 * a search result so the metadata is guaranteed to be that exact title.
 */
export async function lookupMediaDetails(options: {
  title: string;
  type?: MediaType;
  year?: number;
  imdbId?: string;
  posterUrl?: string;
}): Promise<MediaDetails> {
  const type: MediaType = options.type || 'movie';
  const title = options.title.trim();

  let imdbId = options.imdbId && /^tt\d+$/.test(options.imdbId) ? options.imdbId : undefined;
  let posterUrl = bestPosterUrl(options.posterUrl);

  if (!imdbId) {
    const candidates = await searchMedia(title, type);
    const best = candidates[0];
    if (best) {
      imdbId = best.id;
      posterUrl = bestPosterUrl(posterUrl || best.posterUrl);
    }
  }

  let meta: CinemetaMeta | null = null;
  if (imdbId) {
    const kinds: Array<'movie' | 'series'> = type === 'movie' ? ['movie', 'series'] : ['series', 'movie'];
    for (const kind of kinds) {
      const data = await fetchJson<{ meta?: CinemetaMeta }>(
        `${CINEMETA_BASE}/meta/${kind}/${imdbId}.json`,
      );
      if (data?.meta && (data.meta.name || data.meta.description)) {
        meta = data.meta;
        break;
      }
    }
  }

  let resolvedTitle = (meta?.name || title).trim();
  let description = (meta?.description || '').trim();
  let genre = ((meta?.genre?.length ? meta.genre : meta?.genres) || []).join(', ');
  let releaseYear = yearFrom(meta?.releaseInfo) ?? yearFrom(meta?.year) ?? options.year ?? 0;
  let rating = Number(meta?.imdbRating) || 0;
  posterUrl = bestPosterUrl(posterUrl || meta?.poster);

  if (!description && (type === 'series' || type === 'anime')) {
    const show = await fetchJson<TvmazeShow>(
      `https://api.tvmaze.com/singlesearch/shows?q=${encodeURIComponent(title)}`,
    );
    if (show) {
      description = stripHtml(show.summary);
      genre = genre || (show.genres || []).join(', ');
      rating = rating || Number(show.rating?.average) || 0;
      posterUrl = bestPosterUrl(posterUrl || show.image?.original || show.image?.medium);
      releaseYear = releaseYear || yearFrom(show.premiered) || 0;
      if (show.name) resolvedTitle = resolvedTitle || show.name;
    }
  }

  if (!description || !posterUrl) {
    const wiki = await wikipediaSummary(title, type);
    if (wiki) {
      description = description || wiki.extract;
      posterUrl = bestPosterUrl(posterUrl || wiki.image);
      releaseYear = releaseYear || wiki.year || 0;
    }
  }

  return {
    title: resolvedTitle,
    type,
    description,
    genre,
    releaseYear: releaseYear || new Date().getFullYear(),
    rating: Number.isFinite(rating) ? Math.min(10, Math.max(0, rating)) : 0,
    posterUrl: posterUrl || '',
  };
}
