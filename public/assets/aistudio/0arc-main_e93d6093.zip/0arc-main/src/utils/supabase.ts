import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const STORAGE_URL_KEY = '0arc_supabase_url';
const STORAGE_KEY_KEY = '0arc_supabase_anon_key';

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  source: 'env' | 'custom' | 'none';
}

/**
 * Resolves Supabase credentials from import.meta.env, process.env, or user-provided localStorage.
 */
export function getSupabaseConfig(): SupabaseConfig {
  let envUrl = '';
  let envKey = '';

  // Check import.meta.env (Vite standard)
  try {
    if (typeof import.meta !== 'undefined' && import.meta.env) {
      envUrl = (import.meta.env.VITE_SUPABASE_URL as string | undefined)?.trim() || '';
      envKey = (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined)?.trim() || '';
    }
  } catch {}

  // Check process.env fallback (defined by Vite config or Node)
  try {
    if (!envUrl && typeof process !== 'undefined' && process.env) {
      envUrl = (process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL || '').trim();
    }
    if (!envKey && typeof process !== 'undefined' && process.env) {
      envKey = (
        process.env.VITE_SUPABASE_ANON_KEY ||
        process.env.SUPABASE_ANON_KEY ||
        process.env.SUPABASE_SERVICE_ROLE_KEY ||
        ''
      ).trim();
    }
  } catch {}

  if (envUrl && envKey) {
    return { url: envUrl, anonKey: envKey, source: 'env' };
  }

  // Check custom user configuration stored in browser
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const storedUrl = (localStorage.getItem(STORAGE_URL_KEY) || '').trim();
      const storedKey = (localStorage.getItem(STORAGE_KEY_KEY) || '').trim();
      if (storedUrl && storedKey) {
        return { url: storedUrl, anonKey: storedKey, source: 'custom' };
      }
    }
  } catch {}

  const defaultUrl = 'https://xrsioncgmtijyqghjdqb.supabase.co';
  const defaultKey = 'sb_publishable_bN1MZFMYutoAgHAZoZd5UA_46fBGN2P';

  return { url: envUrl || defaultUrl, anonKey: envKey || defaultKey, source: envUrl ? 'env' : 'default' };
}

export function isSupabaseConfigured(): boolean {
  const config = getSupabaseConfig();
  return Boolean(
    config.url &&
    config.url.startsWith('http') &&
    config.anonKey &&
    config.anonKey.length > 20
  );
}

const STORAGE_DISCONNECTED_KEY = '0arc_supabase_disconnected';

export function isCloudSyncEnabled(): boolean {
  if (!isSupabaseConfigured()) return false;
  if (typeof window === 'undefined') return true;
  return localStorage.getItem(STORAGE_DISCONNECTED_KEY) !== 'true';
}

export function setCloudSyncEnabled(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  if (enabled) {
    localStorage.removeItem(STORAGE_DISCONNECTED_KEY);
  } else {
    localStorage.setItem(STORAGE_DISCONNECTED_KEY, 'true');
  }
}

export function saveSupabaseCredentials(url: string, anonKey: string): void {
  if (typeof window === 'undefined') return;
  const cleanUrl = url.trim().replace(/\/+$/, '');
  const cleanKey = anonKey.trim();
  localStorage.setItem(STORAGE_URL_KEY, cleanUrl);
  localStorage.setItem(STORAGE_KEY_KEY, cleanKey);
  localStorage.removeItem(STORAGE_DISCONNECTED_KEY);
  resetSupabaseClient();
}

export function clearSupabaseCredentials(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_URL_KEY);
  localStorage.removeItem(STORAGE_KEY_KEY);
  localStorage.removeItem(STORAGE_DISCONNECTED_KEY);
  resetSupabaseClient();
}

let cachedClient: SupabaseClient | null = null;
let lastUsedUrl = '';
let lastUsedKey = '';

export function getSupabaseClient(): SupabaseClient | null {
  const config = getSupabaseConfig();
  if (!config.url || !config.anonKey) {
    return null;
  }

  if (cachedClient && lastUsedUrl === config.url && lastUsedKey === config.anonKey) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(config.url, config.anonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
    lastUsedUrl = config.url;
    lastUsedKey = config.anonKey;
    return cachedClient;
  } catch (err) {
    console.error('Failed to initialize Supabase client:', err);
    return null;
  }
}

export function resetSupabaseClient(): void {
  cachedClient = null;
  lastUsedUrl = '';
  lastUsedKey = '';
}

/**
 * Validate a connection to Supabase using given or current credentials.
 */
export async function testSupabaseConnection(
  targetUrl?: string,
  targetKey?: string
): Promise<{ ok: boolean; message: string }> {
  const url = (targetUrl || getSupabaseConfig().url).trim().replace(/\/+$/, '');
  const key = (targetKey || getSupabaseConfig().anonKey).trim();

  if (!url || !key) {
    return { ok: false, message: 'Both Supabase Project URL and API Key are required.' };
  }

  if (!url.startsWith('https://') && !url.startsWith('http://')) {
    return { ok: false, message: 'Supabase URL must start with https://' };
  }

  try {
    const testClient = createClient(url, key, {
      auth: { persistSession: false },
    });
    // Test auth endpoint ping
    const { error } = await testClient.auth.getSession();
    if (error && !error.message.includes('Auth session missing')) {
      return { ok: false, message: error.message };
    }
    return { ok: true, message: 'Successfully connected to Supabase.' };
  } catch (err) {
    return {
      ok: false,
      message: err instanceof Error ? err.message : 'Failed to reach Supabase project.',
    };
  }
}

/**
 * Cookie helpers for cross-request session tokens
 */
function setCookie(name: string, value: string, days = 60) {
  if (typeof document === 'undefined') return;
  document.cookie = `${name}=${value}; path=/; max-age=${days * 86400}; SameSite=Lax`;
}

function getCookie(name: string): string | null {
  if (typeof document === 'undefined') return null;
  const parts = document.cookie.split('; ');
  for (const part of parts) {
    const [k, ...rest] = part.split('=');
    if (k === name) return rest.join('=');
  }
  return null;
}

function removeCookie(name: string) {
  if (typeof document === 'undefined') return;
  document.cookie = `${name}=; path=/; max-age=0; SameSite=Lax`;
}

export const COOKIE_SESSION_TOKEN = '0arc_supabase_session_token';
export const COOKIE_USER_ID = '0arc_supabase_user_id';

export function writeSessionCookie(token: string, userId: string) {
  setCookie(COOKIE_SESSION_TOKEN, token, 60);
  setCookie(COOKIE_USER_ID, userId, 60);
}

export function readSessionCookie(): { token: string | null; userId: string | null } {
  return {
    token: getCookie(COOKIE_SESSION_TOKEN),
    userId: getCookie(COOKIE_USER_ID),
  };
}

export function clearSessionCookies() {
  removeCookie(COOKIE_SESSION_TOKEN);
  removeCookie(COOKIE_USER_ID);
}

export function supabaseSessionHeader(): string | null {
  const { token } = readSessionCookie();
  return token ? `Bearer ${token}` : null;
}
