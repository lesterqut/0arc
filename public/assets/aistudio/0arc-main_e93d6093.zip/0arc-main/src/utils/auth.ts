/**
 * Secure authentication utilities for 0arc
 * Provides cryptographically secure password hashing (PBKDF2-HMAC-SHA256 with unique salts),
 * strict input validation against injection and manipulation, and secure user storage.
 */

export interface StoredUser {
  id: string;
  username: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
}

const USERS_STORAGE_KEY = '0arc_registered_accounts_v1';
const CURRENT_SESSION_KEY = '0arc_active_session_user_v1';

// Convert ArrayBuffer to Hex string
function bufferToHex(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

// Convert Hex string to Uint8Array
function hexToBytes(hex: string): Uint8Array {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

// Generate cryptographically strong random salt
export function generateSalt(length = 16): string {
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return bufferToHex(array.buffer);
}

// Hash password with salt using PBKDF2 with SHA-256 (100,000 iterations)
export async function hashPassword(password: string, saltHex: string): Promise<string> {
  const enc = new TextEncoder();
  const passwordKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const saltBytes = hexToBytes(saltHex);
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBytes as BufferSource,
      iterations: 100000,
      hash: 'SHA-256',
    },
    passwordKey,
    256
  );

  return bufferToHex(derivedBits);
}

// Constant-time string comparison to prevent timing attacks
export function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

// Strict username sanitizer: alphanumeric and underscores only, 3 to 30 characters
export function validateUsername(username: string): { valid: boolean; error?: string; sanitized: string } {
  const trimmed = username.trim();
  if (!trimmed) {
    return { valid: false, error: 'Username is required.', sanitized: '' };
  }
  if (trimmed.length < 3) {
    return { valid: false, error: 'Username must be at least 3 characters long.', sanitized: '' };
  }
  if (trimmed.length > 30) {
    return { valid: false, error: 'Username cannot exceed 30 characters.', sanitized: '' };
  }
  // Prevent SQL/script injection characters, spaces, HTML tags
  const validRegex = /^[a-zA-Z0-9_]+$/;
  if (!validRegex.test(trimmed)) {
    return {
      valid: false,
      error: 'Username can only contain letters, numbers, and underscores (no spaces or special symbols).',
      sanitized: '',
    };
  }
  return { valid: true, sanitized: trimmed };
}

// Password validation
export function validatePassword(password: string): { valid: boolean; error?: string } {
  if (!password) {
    return { valid: false, error: 'Password is required.' };
  }
  if (password.length < 6) {
    return { valid: false, error: 'Password must be at least 6 characters long.' };
  }
  if (password.length > 128) {
    return { valid: false, error: 'Password is too long (maximum 128 characters).' };
  }
  return { valid: true };
}

// Get all stored users safely
export function getStoredUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// Save users safely
export function saveStoredUsers(users: StoredUser[]): void {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Failed to save users store', err);
  }
}

// Get active session username
export function getActiveSessionUsername(): string | null {
  try {
    return localStorage.getItem(CURRENT_SESSION_KEY);
  } catch {
    return null;
  }
}

// Set active session username
export function setActiveSessionUsername(username: string | null): void {
  try {
    if (username) {
      localStorage.setItem(CURRENT_SESSION_KEY, username);
    } else {
      localStorage.removeItem(CURRENT_SESSION_KEY);
    }
  } catch (err) {
    console.error('Failed to update session store', err);
  }
}
