/**
 * Client-side helpers for checking whether Supabase is configured enough to
 * run cross-device cloud sync.
 */
import { isSupabaseConfigured, getSupabaseConfig } from './supabase';

export function supabaseEnvConfigured(): boolean {
  return isSupabaseConfigured();
}

export function supabaseMissingReason(): string | null {
  const config = getSupabaseConfig();
  if (!config.url && !config.anonKey) {
    return 'Supabase credentials have not been configured yet.';
  }
  if (!config.url) {
    return 'Supabase project URL is missing.';
  }
  if (!config.anonKey) {
    return 'Supabase anon key is missing.';
  }
  if (config.anonKey.length < 20) {
    return 'Supabase anon key appears invalid or truncated.';
  }
  return null;
}
