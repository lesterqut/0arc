/**
 * Local dev / preview server.
 * Production on Vercel uses the static `dist` build plus the serverless
 * functions in /api (see api/imdb/* and api/gemini/*), which share this logic.
 */
import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { lookupMedia, resolveMediaDetails, searchImdb, type MediaKind } from './api/_lib/media';
import { handleSignup, handleSignin, handleSignout } from './api/supabase/auth';
import { handleSupabaseData } from './api/supabase/data';
import type { ApiRequest, ApiResponse } from './api/_lib/types';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

app.get('/api/imdb/search', async (req, res) => {
  const query = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  const type = typeof req.query.type === 'string' ? req.query.type.trim() : undefined;

  if (!query) {
    return res.json({ results: [] });
  }

  return res.json({ results: await searchImdb(query, type) });
});

app.get('/api/imdb/q', async (req, res) => {
  const query = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  const type = typeof req.query.type === 'string' ? req.query.type.trim() : undefined;

  if (!query) {
    return res.json({ results: [] });
  }

  return res.json({ results: await searchImdb(query, type) });
});

app.post('/api/imdb/details', async (req, res) => {
  const { title, year, type, posterUrl } = req.body ?? {};

  if (!title || typeof title !== 'string' || !title.trim()) {
    return res.status(400).json({ error: 'Title is required' });
  }

  const requestedType: MediaKind = type === 'series' || type === 'anime' ? type : 'movie';
  const details = await resolveMediaDetails(
    title.trim(),
    year ? Number(year) : undefined,
    requestedType,
    typeof posterUrl === 'string' ? posterUrl : undefined
  );

  return res.json(details);
});

app.post('/api/gemini/media-lookup', async (req, res) => {
  const { title, type } = req.body ?? {};

  if (!title || typeof title !== 'string' || !title.trim()) {
    return res.status(400).json({ error: 'Title is required' });
  }

  return res.json(await lookupMedia(title.trim(), typeof type === 'string' ? type : 'movie'));
});

/**
 * Cloud vault routes. Mirrors `api/supabase/route.ts` on Vercel so the same
 * Supabase-backed sign-up, sign-in and sync work in local dev / preview.
 */
app.all('/api/supabase/*', async (req, res) => {
  const pathname = req.path;

  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, error: 'POST only' });
  }

  const apiReq: ApiRequest = {
    method: req.method,
    url: pathname,
    headers: req.headers as Record<string, string | undefined>,
    body: req.body && Object.keys(req.body).length ? JSON.stringify(req.body) : '{}',
    query: req.query as Record<string, string>,
  };

  let response: ApiResponse;
  try {
    switch (pathname) {
      case '/api/supabase/auth/signup':
        response = await handleSignup(apiReq);
        break;
      case '/api/supabase/auth/signin':
        response = await handleSignin(apiReq);
        break;
      case '/api/supabase/auth/signout':
        response = await handleSignout(apiReq);
        break;
      case '/api/supabase/data':
        response = await handleSupabaseData(apiReq);
        break;
      default:
        response = { status: 404, body: { ok: false, error: 'Not found' } };
    }
  } catch (error) {
    response = {
      status: 500,
      body: { ok: false, error: error instanceof Error ? error.message : 'Server error' },
    };
  }

  return res.status(response.status).json(response.body);
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`0arc server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
