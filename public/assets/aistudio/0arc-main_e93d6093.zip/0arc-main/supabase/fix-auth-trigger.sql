-- Repair the 0arc sign-up trigger.
--
-- Symptom: creating a user fails with
--   500 "Database error creating new user" / "Database error saving new user".
-- Cause: the trigger function cannot resolve the 0arc tables at run time
-- (search_path / ownership), so the auth.users insert is rolled back.
--
-- Paste this whole file into Supabase → SQL Editor → Run. It is safe to run
-- repeatedly and does not delete any data.

create or replace function public.fn_0arc_on_auth_user_created()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  new_username text;
begin
  new_username := coalesce(
    NEW.raw_user_meta_data->>'username',
    lower(regexp_replace(NEW.email, '[^a-z0-9_]+', '_', 'gi'))
  );

  insert into public."0arc_users" (id, username)
    values (NEW.id, new_username)
    on conflict (id) do update set username = excluded.username;

  insert into public."0arc_settings" (user_id, confirm_before_delete, default_archive_view)
    values (NEW.id, true, 'overview')
    on conflict (user_id) do nothing;

  return null;
end;
$$;

alter function public.fn_0arc_on_auth_user_created() owner to postgres;

drop trigger if exists "on_auth_user_created" on auth.users;

create trigger "on_auth_user_created"
  after insert on auth.users
  for each row execute function public.fn_0arc_on_auth_user_created();

-- If sign-up still fails after this, check Supabase → Logs → Postgres for the
-- real error; it will name the exact constraint or table that failed.
