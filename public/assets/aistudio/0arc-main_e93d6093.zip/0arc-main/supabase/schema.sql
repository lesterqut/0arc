-- 0arc Single-User Private Vault Schema for Supabase
-- Run this in your Supabase Dashboard -> SQL Editor

-- 1. Master Vaults Table
create table if not exists "0arc_vaults" (
  id           text primary key default 'main',
  tools        jsonb not null default '[]'::jsonb,
  notes        jsonb not null default '[]'::jsonb,
  media        jsonb not null default '[]'::jsonb,
  settings     jsonb not null default '{}'::jsonb,
  updated_at   timestamptz not null default now()
);

-- 2. Granular Tables
create table if not exists "0arc_tools" (
  id           uuid primary key,
  user_id      uuid,
  title        text not null,
  description  text not null default '',
  url          text,
  category     text not null default 'Other',
  tags         text[] not null default '{}',
  is_favorite  boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists "0arc_notes" (
  id           uuid primary key,
  user_id      uuid,
  title        text not null,
  content      text not null default '',
  category     text not null default 'Inbox',
  tags         text[] not null default '{}',
  is_favorite  boolean not null default false,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists "0arc_media" (
  id               uuid primary key,
  user_id          uuid,
  title            text not null,
  type             text not null default 'movie',
  poster_url       text,
  description      text not null default '',
  genre            text not null default '',
  release_year     integer,
  rating           numeric,
  status           text not null default 'want_to_watch',
  notes            text,
  progress_current integer,
  progress_total   integer,
  is_favorite      boolean not null default false,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create table if not exists "0arc_settings" (
  id                     text primary key default 'main',
  user_id                uuid,
  confirm_before_delete  boolean not null default true,
  default_archive_view   text not null default 'overview',
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

-- 3. Disable RLS for single-user personal access (no login required)
alter table if exists "0arc_vaults" disable row level security;
alter table if exists "0arc_tools" disable row level security;
alter table if exists "0arc_notes" disable row level security;
alter table if exists "0arc_media" disable row level security;
alter table if exists "0arc_settings" disable row level security;

-- 4. Ensure user_id is nullable on existing tables
alter table if exists "0arc_tools" alter column user_id drop not null;
alter table if exists "0arc_notes" alter column user_id drop not null;
alter table if exists "0arc_media" alter column user_id drop not null;
alter table if exists "0arc_settings" alter column user_id drop not null;
